import service.appointment.AppointmentService;
import service.checkin.CheckinService;
import service.triage.TriageService;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceInfo;
import java.net.InetAddress;
import java.util.logging.Logger;

public class ServiceRegistration implements Runnable {

    private CheckinService checkinService;
    private AppointmentService appointmentService;
    private TriageService triageService;

    ServiceRegistration() {
        checkinService = new CheckinService();
        appointmentService = new AppointmentService();
        triageService = new TriageService();
    }

    @Override
    public void run() {
        Logger logger = Logger.getLogger(ServiceRegistration.class.getName());
        try {
            JmDNS jmdns;
            jmdns = JmDNS.create(InetAddress.getLocalHost());
            ServiceInfo appointment = ServiceInfo.create("_grpc._tcp.local.", "Appointment Service", 3001, "path=/appointment");
            ServiceInfo checkin = ServiceInfo.create("_grpc._tcp.local.", "Checkin Service", 5678, "path=/checkin");
            ServiceInfo triage = ServiceInfo.create("_grpc._tcp.local.", "Triage Service", 9012, "path=/triage");

            // Register the services
            jmdns.registerService(appointment);
            jmdns.registerService(checkin);
            jmdns.registerService(triage);
            logger.info("Services registered");

            // Start the services
            triageService.startServer("9012");
            appointmentService.startServer("3001");
            checkinService.startServer("5678");


        } catch (Exception e) {
            logger.warning("Cannot get local host " + e.getMessage());
            System.exit(1);
        }
    }
}
