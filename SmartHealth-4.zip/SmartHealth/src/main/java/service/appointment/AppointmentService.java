package service.appointment;

import io.grpc.Grpc;
import io.grpc.InsecureServerCredentials;
import io.grpc.Server;
import io.grpc.stub.StreamObserver;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class AppointmentService  extends AppointmentServiceGrpc.AppointmentServiceImplBase{
    ArrayList<AppointmentDefinition.Appointment> appointments;

    public AppointmentService() {
        appointments = new ArrayList<>();
    }
    private Server server;
    public void startServer(String port) throws Exception{
        this.server = Grpc.newServerBuilderForPort(Integer.parseInt(port), InsecureServerCredentials.create())
                .addService(this)
                .build()
                .start();

    }


    public void stop() throws InterruptedException {
        if (server != null) {
            server.shutdown().awaitTermination(30, TimeUnit.SECONDS);
        }
    }

    /**
     * @param responseObserver
     */
    @Override
    public StreamObserver<AppointmentDefinition.Appointment> createAppointment(StreamObserver<AppointmentDefinition.Appointment> responseObserver) {
        return new StreamObserver<>() {
            @Override
            public void onNext(AppointmentDefinition.Appointment value) {
                appointments.add(value);
            }

            @Override
            public void onError(Throwable t) {

            }

            @Override
            public void onCompleted() {

            }
        };
    }

    /**
     * @param responseObserver
     */
    @Override
    public StreamObserver<AppointmentDefinition.Appointment> modifyAppointment(StreamObserver<AppointmentDefinition.Appointment> responseObserver) {
        return new StreamObserver<>() {
            @Override
            public void onNext(AppointmentDefinition.Appointment value) {
                // Search
            }

            @Override
            public void onError(Throwable t) {

            }

            @Override
            public void onCompleted() {

            }
        };
    }

    /**
     * @param request
     * @param responseObserver
     */
    @Override
    public void cancelAppointment(AppointmentDefinition.CancelAppointmentRequest request, StreamObserver<AppointmentDefinition.CancelAppointmentResponse> responseObserver) {
        int id = Integer.parseInt(request.getAppointmentId());
        appointments.remove(id);
    }
}
