package service.appointment;

import io.grpc.Channel;
import io.grpc.stub.StreamObserver;

public class AppointmentClient {

    private AppointmentServiceGrpc.AppointmentServiceBlockingStub blockingStub;
    private AppointmentServiceGrpc.AppointmentServiceStub asyncStub;
    public AppointmentClient(Channel channel) {
        blockingStub = AppointmentServiceGrpc.newBlockingStub(channel);
        asyncStub = AppointmentServiceGrpc.newStub(channel);
    }

    public AppointmentDefinition.Appointment createAppointment(AppointmentDefinition.Appointment appointment) {

        // create new stream
        StreamObserver<AppointmentDefinition.Appointment> requestObserver = asyncStub.createAppointment(new StreamObserver<AppointmentDefinition.Appointment>() {
            @Override
            public void onNext(AppointmentDefinition.Appointment value) {
                System.out.println("Received response from server: " + value);
            }

            @Override
            public void onError(Throwable t) {
                System.out.println("Error: " + t.getMessage());
            }

            @Override
            public void onCompleted() {
                System.out.println("Server has completed sending us something");
            }
        });

        requestObserver.onNext(appointment);
        requestObserver.onCompleted();
        return appointment;
    }

    public AppointmentDefinition.Appointment modifyAppointment(AppointmentDefinition.Appointment appointment) {
        // create new stream
        StreamObserver<AppointmentDefinition.Appointment> requestObserver = asyncStub.modifyAppointment(new StreamObserver<>() {
            @Override
            public void onNext(AppointmentDefinition.Appointment value) {
                System.out.println("Received response from server: " + value);
            }

            @Override
            public void onError(Throwable t) {
                System.out.println("Error: " + t.getMessage());
            }

            @Override
            public void onCompleted() {
                System.out.println("Server has completed sending us something");
            }
        });

        requestObserver.onNext(appointment);
        return appointment;
    }

    public void deleteAppointment(int id) {

        // create new stream
        StreamObserver<AppointmentDefinition.CancelAppointmentResponse> appointmentResponseStreamObserver = new StreamObserver<AppointmentDefinition.CancelAppointmentResponse>() {
            @Override
            public void onNext(AppointmentDefinition.CancelAppointmentResponse value) {

            }

            @Override
            public void onError(Throwable t) {

            }

            @Override
            public void onCompleted() {

            }
        };
        asyncStub.cancelAppointment(AppointmentDefinition.CancelAppointmentRequest.newBuilder().setAppointmentId(String.valueOf(id)).build(),appointmentResponseStreamObserver);
    }
}
