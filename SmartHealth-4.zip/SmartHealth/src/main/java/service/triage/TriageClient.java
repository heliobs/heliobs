package service.triage;

public class TriageClient {

}
