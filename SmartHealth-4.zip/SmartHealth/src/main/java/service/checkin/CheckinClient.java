package service.checkin;

public class CheckinClient {

}
