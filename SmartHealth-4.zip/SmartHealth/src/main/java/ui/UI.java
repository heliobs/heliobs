package ui;

public class UI {
    public UI() {
        new Dashboard();
    }
}
