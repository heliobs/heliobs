package ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class Triage extends JFrame{
    private JPanel bannerPanel, tablePanel;
    Triage() {
        // Setup Screen
        setTitle("Triage");
        setSize(800, 600);

        // set up the frame
        setResizable(false);
        setLocationRelativeTo(null);

        // Jlabel
        JLabel bannerLabel = new JLabel("Triage Service");
        bannerLabel.setForeground(Color.WHITE);
        bannerLabel.setFont(new Font("Arial", Font.BOLD, 24));

        // set up the banner panel
        bannerPanel = new JPanel();
        bannerPanel.setBackground(Color.BLUE);

        // setup TablePanel
        tablePanel = new JPanel(new BorderLayout());
        setupTable();

        bannerPanel.add(bannerLabel);
        add(bannerPanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
        setVisible(true);
    }


    void setupTable() {
        String[] columnNames = {"Patient ID", "TEMP", "BPM", "SYMPTOMS"};
        Object[][] rowData = {
                {12, 34, 56, "Nauseatic"},
        };

        // Create the table model
        DefaultTableModel model = new DefaultTableModel(rowData, columnNames) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Make all cells editable
                return true;
            }
        };

        // Create the table and set its model
        JTable table = new JTable(model);

        // Add the table to a scroll pane
        JScrollPane scrollPane = new JScrollPane(table);

        tablePanel.add(scrollPane, BorderLayout.CENTER);


        // Create edit
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.BLUE);
        BoxLayout boxLayout = new BoxLayout(buttonPanel, BoxLayout.X_AXIS);
        buttonPanel.setLayout(boxLayout); // Set the layout to horizontal

        tablePanel.add(buttonPanel, BorderLayout.SOUTH);
        // Create buttons
        JButton save = new JButton("Save Triage");
        JButton newTriage = new JButton("New Triage");
        JButton deleteTriage = new JButton("Delete Triage");

        // Add padding between buttons
        int buttonPadding = 24;
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(buttonPadding, buttonPadding, buttonPadding, buttonPadding));

        newTriage.addActionListener(e -> {
            model.addRow(new Object[]{});
        });

        deleteTriage.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                model.removeRow(selectedRow);
            }
        });


        // Add the buttons
        buttonPanel.add(save);
        buttonPanel.add(Box.createHorizontalGlue());
        buttonPanel.add(newTriage);
        buttonPanel.add(Box.createHorizontalGlue());
        buttonPanel.add(deleteTriage);
    }
}
