package ui;

import service.appointment.AppointmentService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class Appointment  extends JFrame{
    private JPanel bannerPanel, tablePanel;
    private AppointmentService appointmentService;
    Appointment() {
        // Setup Screen
        setTitle("Appointments");
        setSize(800, 600);

        // set up the frame
        setResizable(false);
        setLocationRelativeTo(null);

        JLabel bannerLabel = new JLabel("Appointments");
        bannerLabel.setForeground(Color.WHITE);
        bannerLabel.setFont(new Font("Arial", Font.BOLD, 24));

        // set up the banner panel
        bannerPanel = new JPanel();
        bannerPanel.setBackground(Color.BLUE);

        // setup TablePanel
        tablePanel = new JPanel(new BorderLayout());
        setupTable();

        // connect to the service
        appointmentService = new AppointmentService();

        bannerPanel.add(bannerLabel);
        add(bannerPanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
        setVisible(true);
    }


    void setupTable() {
        String[] columnNames = {"Name", "Age", "Gender", "DoctorID", "Date", "Time"};
        Object[][] rowData = {
                {"John Doe", 30, "Male", 233, "12/5/2023", "20:23"},
                {"Jane Smith", 25, "Female", 233, "13/5/2023","19:45"},
                {"Bob Johnson", 40, "Male", 902, "14/5/2023","17:12"},
        };

        // Create the table model
        DefaultTableModel model = new DefaultTableModel(rowData, columnNames) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Make all cells editable
                return true;
            }
        };

        // Create the table and set its model
        JTable table = new JTable(model);

        // Add the table to a scroll pane
        JScrollPane scrollPane = new JScrollPane(table);

        tablePanel.add(scrollPane, BorderLayout.CENTER);


        // Create edit
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.BLUE);
        BoxLayout boxLayout = new BoxLayout(buttonPanel, BoxLayout.X_AXIS);
        buttonPanel.setLayout(boxLayout); // Set the layout to horizontal

        tablePanel.add(buttonPanel, BorderLayout.SOUTH);
        // Create buttons
        JButton save = new JButton("Save Appointment");
        JButton newAppointment = new JButton("New Appointment");
        JButton deleteAppointment = new JButton("Delete Appointment");
        JButton cancelAppointment = new JButton("Cancel Appointment");

        save.addActionListener(e-> {
            // Save the data
            System.out.println("Saving data");
        });

        newAppointment.addActionListener(e-> {
            model.addRow(new Object[]{"", 0, "",0,"",""});
        });

        deleteAppointment.addActionListener(e-> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                model.removeRow(row);
            }
        });

        cancelAppointment.addActionListener(e-> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                model.removeRow(row);
            }
        });

        // Add padding between buttons
        int buttonPadding = 24;
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(buttonPadding, buttonPadding, buttonPadding, buttonPadding));


        // Add the buttons
        buttonPanel.add(save);
        buttonPanel.add(Box.createHorizontalGlue());
        buttonPanel.add(newAppointment);
        buttonPanel.add(Box.createHorizontalGlue());
        buttonPanel.add(deleteAppointment);
        buttonPanel.add(Box.createHorizontalGlue());
        buttonPanel.add(cancelAppointment);
    }
}
