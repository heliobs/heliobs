package ui;

import java.awt.*;
import java.net.URL;
import javax.swing.*;

public class Dashboard extends JFrame {
        private final JPanel bannerPanel, buttonPanel;
        private final JButton appointmentButton, triageButton, visitorButton;

        public Dashboard() {
            // set up the frame
            setTitle("Hospital Dashboard");
            setSize(800, 600);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            // set up the banner panel
            bannerPanel = new JPanel();
            bannerPanel.setBackground(Color.BLUE);
            JLabel bannerLabel = new JLabel("Hospital Dashboard");
            bannerLabel.setForeground(Color.WHITE);
            bannerLabel.setFont(new Font("Arial", Font.BOLD, 24));
            bannerPanel.add(bannerLabel);
            add(bannerPanel, BorderLayout.NORTH);


            // set up the button panel
            buttonPanel = new JPanel(new GridLayout(3, 1, 10, 10));
            buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
            appointmentButton = new JButton("Smart Appointment Scheduling");
            triageButton = new JButton("Triage Procedure");
            visitorButton = new JButton("Visitors Check-in");
            buttonPanel.add(appointmentButton);
            buttonPanel.add(triageButton);
            buttonPanel.add(visitorButton);
            add(buttonPanel, BorderLayout.CENTER);


            // Setup Onclick listeners
            appointmentButton.addActionListener(e->{
                new Appointment();
            });

            visitorButton.addActionListener(e -> {
                new Checkin();
            });

            triageButton.addActionListener(e-> {
                new Triage();
            });

            // set up the frame
            setResizable(false);
            setLocationRelativeTo(null);
            setVisible(true);
        }


    private URL getResource(String filename) {
        return getClass().getClassLoader().getResource(filename);
    }
}
