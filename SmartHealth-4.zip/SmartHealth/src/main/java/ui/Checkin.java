package ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class Checkin extends JFrame{
    private JPanel bannerPanel, tablePanel;
    Checkin() {
        // Setup Screen
        setTitle("Checkins");
        setSize(800, 600);

        // set up the frame
        setResizable(false);
        setLocationRelativeTo(null);

        // Jlabel
        JLabel bannerLabel = new JLabel("Visitor Checkins");
        bannerLabel.setForeground(Color.WHITE);
        bannerLabel.setFont(new Font("Arial", Font.BOLD, 24));

        // set up the banner panel
        bannerPanel = new JPanel();
        bannerPanel.setBackground(Color.BLUE);

        // setup TablePanel
        tablePanel = new JPanel(new BorderLayout());
        setupTable();

        bannerPanel.add(bannerLabel);
        add(bannerPanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
        setVisible(true);
    }


    void setupTable() {
        String[] columnNames = {"Name", "Age", "Gender", "Phone", "Purpose", "Time In", "Time Out"};
        Object[][] rowData = {

        };

        // Create the table model
        DefaultTableModel model = new DefaultTableModel(rowData, columnNames) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Make all cells editable
                return true;
            }
        };

        // Create the table and set its model
        JTable table = new JTable(model);

        // Add the table to a scroll pane
        JScrollPane scrollPane = new JScrollPane(table);

        tablePanel.add(scrollPane, BorderLayout.CENTER);


        // Create edit
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.BLUE);
        BoxLayout boxLayout = new BoxLayout(buttonPanel, BoxLayout.X_AXIS);
        buttonPanel.setLayout(boxLayout); // Set the layout to horizontal

        tablePanel.add(buttonPanel, BorderLayout.SOUTH);
        // Create buttons
        JButton save = new JButton("Save checkin");
        JButton newCheckin = new JButton("New checkin");
        JButton deleteCheckin = new JButton("Delete checkin");



        // Add padding between buttons
        int buttonPadding = 24;
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(buttonPadding, buttonPadding, buttonPadding, buttonPadding));

        // add action listeners
        save.addActionListener(e -> {
           // Alert user that the appointment has been saved
              JOptionPane.showMessageDialog(null, "Checkin saved");
        });


        newCheckin.addActionListener(e -> {
           //// create new checkin
            model.addRow(new Object[]{"", "", "", "", "", "", ""});
        });

        deleteCheckin.addActionListener(e -> {
           // delete checkin
            model.removeRow(table.getSelectedRow());
            // Alert user that the appointment has been deleted
            JOptionPane.showMessageDialog(null, "Checkin deleted");
        });


        // Add the buttons
        buttonPanel.add(save);
        buttonPanel.add(Box.createHorizontalGlue());
        buttonPanel.add(newCheckin);
        buttonPanel.add(Box.createHorizontalGlue());
        buttonPanel.add(deleteCheckin);

    }
}
